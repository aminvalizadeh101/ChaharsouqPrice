package ir.chaharsouq.price;

import android.app.Activity;
import android.os.Bundle;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.Typeface;
import android.graphics.Color;
import android.content.ContentValues;
import android.content.Intent;
import android.net.Uri;
import android.provider.MediaStore;
import android.view.Gravity;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;
import java.io.OutputStream;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;

public class MainActivity extends Activity {
    private Bitmap rendered;
    private TextView status;
    private ImageView preview;

    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        getWindow().setStatusBarColor(Color.rgb(20,41,31));
        getWindow().setNavigationBarColor(Color.rgb(20,41,31));
        buildUi();
    }

    private int dp(float v) { return (int)(v * getResources().getDisplayMetrics().density + .5f); }
    private TextView text(String s, int size, int color) {
        TextView t = new TextView(this); t.setText(s); t.setTextSize(size); t.setTextColor(color);
        t.setGravity(Gravity.CENTER); t.setPadding(dp(8),dp(8),dp(8),dp(8)); return t;
    }
    private Button button(String s) {
        Button b = new Button(this); b.setText(s); b.setAllCaps(false); return b;
    }
    private void buildUi() {
        LinearLayout root = new LinearLayout(this); root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(dp(18),dp(12),dp(18),dp(18)); root.setBackgroundColor(Color.rgb(247,247,244));
        TextView title = text("چهارسوق | تولید بنر قیمت",22,Color.WHITE); title.setBackgroundColor(Color.rgb(20,41,31));
        root.addView(title,new LinearLayout.LayoutParams(-1,dp(64)));
        status = text("اتصال منبع قیمت در انتظار تکمیل است",14,Color.rgb(120,75,20));
        root.addView(status,new LinearLayout.LayoutParams(-1,dp(56)));
        preview = new ImageView(this); preview.setAdjustViewBounds(true); preview.setScaleType(ImageView.ScaleType.FIT_CENTER);
        try { preview.setImageBitmap(BitmapFactory.decodeStream(getAssets().open("banner_template.jpg"))); } catch(Exception ignored) {}
        LinearLayout.LayoutParams pp = new LinearLayout.LayoutParams(-1,0,1); pp.topMargin=dp(6); pp.bottomMargin=dp(8); root.addView(preview,pp);
        Button refresh=button("دریافت قیمت از Tala.ir");
        refresh.setOnClickListener(v -> Toast.makeText(this,"اتصال خودکار تا زمان تأیید مسیر رسمی داده فعال نمی‌شود.",Toast.LENGTH_LONG).show());
        root.addView(refresh,new LinearLayout.LayoutParams(-1,dp(52)));
        Button make=button("تولید بنر قیمت");
        make.setOnClickListener(v -> Toast.makeText(this,"برای جلوگیری از انتشار نرخ اشتباه، ابتدا اتصال واقعی قیمت باید تکمیل شود.",Toast.LENGTH_LONG).show());
        root.addView(make,new LinearLayout.LayoutParams(-1,dp(52)));
        Button save=button("ذخیره تصویر"); save.setOnClickListener(v -> saveImage()); root.addView(save,new LinearLayout.LayoutParams(-1,dp(50)));
        Button share=button("اشتراک‌گذاری"); share.setOnClickListener(v -> shareImage()); root.addView(share,new LinearLayout.LayoutParams(-1,dp(50)));
        setContentView(root);
    }

    // Called only after a verified price adapter supplies all six values in rial.
    private Bitmap renderBanner(String ounce, String mithqal, String gram18, String emami, String half, String quarter) throws Exception {
        Bitmap base = BitmapFactory.decodeStream(getAssets().open("banner_template.jpg"));
        Bitmap out = base.copy(Bitmap.Config.ARGB_8888,true); Canvas c = new Canvas(out);
        Paint p = new Paint(Paint.ANTI_ALIAS_FLAG|Paint.SUBPIXEL_TEXT_FLAG); p.setColor(Color.WHITE); p.setTypeface(Typeface.create("sans-serif",Typeface.BOLD));
        float sx=out.getWidth()/864f, sy=out.getHeight()/1536f;
        p.setTextSize(45*sx); p.setTextAlign(Paint.Align.LEFT);
        c.drawText(ounce,92*sx,410*sy,p); c.drawText(mithqal,92*sx,525*sy,p); c.drawText(gram18,92*sx,650*sy,p);
        c.drawText(emami,92*sx,985*sy,p); c.drawText(half,92*sx,1100*sy,p); c.drawText(quarter,92*sx,1215*sy,p);
        p.setTextSize(34*sx); p.setTextAlign(Paint.Align.CENTER);
        String date = new SimpleDateFormat("yyyy/MM/dd",new Locale("fa","IR")).format(new Date());
        String time = new SimpleDateFormat("HH:mm",new Locale("fa","IR")).format(new Date());
        c.drawText(date,545*sx,260*sy,p); p.setTextAlign(Paint.Align.CENTER); c.drawText(time,235*sx,260*sy,p);
        return out;
    }

    private void saveImage() {
        if (rendered==null) { Toast.makeText(this,"ابتدا دریافت و تأیید قیمت‌ها باید فعال شود.",Toast.LENGTH_LONG).show(); return; }
        try {
            ContentValues v=new ContentValues(); v.put(MediaStore.Images.Media.DISPLAY_NAME,"Chaharsouq-"+System.currentTimeMillis()+".png");
            v.put(MediaStore.Images.Media.MIME_TYPE,"image/png"); v.put(MediaStore.Images.Media.RELATIVE_PATH,"Pictures/Chaharsouq");
            Uri u=getContentResolver().insert(MediaStore.Images.Media.EXTERNAL_CONTENT_URI,v);
            OutputStream os=getContentResolver().openOutputStream(u); rendered.compress(Bitmap.CompressFormat.PNG,100,os); os.close();
            Toast.makeText(this,"تصویر در گالری ذخیره شد.",Toast.LENGTH_SHORT).show();
        } catch(Exception e) { Toast.makeText(this,"ذخیره تصویر ناموفق بود.",Toast.LENGTH_LONG).show(); }
    }
    private void shareImage() {
        if (rendered==null) { Toast.makeText(this,"ابتدا بنر معتبر تولید شود.",Toast.LENGTH_LONG).show(); return; }
        try {
            ContentValues v=new ContentValues(); v.put(MediaStore.Images.Media.DISPLAY_NAME,"Chaharsouq-share.png"); v.put(MediaStore.Images.Media.MIME_TYPE,"image/png"); v.put(MediaStore.Images.Media.RELATIVE_PATH,"Pictures/Chaharsouq");
            Uri u=getContentResolver().insert(MediaStore.Images.Media.EXTERNAL_CONTENT_URI,v); OutputStream os=getContentResolver().openOutputStream(u); rendered.compress(Bitmap.CompressFormat.PNG,100,os); os.close();
            Intent i=new Intent(Intent.ACTION_SEND); i.setType("image/png"); i.putExtra(Intent.EXTRA_STREAM,u); i.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION); startActivity(Intent.createChooser(i,"اشتراک‌گذاری بنر چهارسوق"));
        } catch(Exception e) { Toast.makeText(this,"اشتراک‌گذاری ناموفق بود.",Toast.LENGTH_LONG).show(); }
    }
}
